package mowItnow.mowItnow;

public enum Direction {
	NORTH('N'), EAST('E'), SOUTH('S'), WEST('W');

	private final char inner;
	private Direction clockwise;
	private Direction anticlockwise;

	static {
		NORTH.clockwise = EAST;
		EAST.clockwise = SOUTH;
		SOUTH.clockwise = WEST;
		WEST.clockwise = NORTH;
		NORTH.anticlockwise = WEST;
		EAST.anticlockwise = NORTH;
		SOUTH.anticlockwise = EAST;
		WEST.anticlockwise = SOUTH;
	}

	Direction(final char val) {
	    inner = val;
	  }

	@Override
	public String toString() {
		return String.valueOf(inner);
	}

	public static Direction parse(char value) throws DirectionParseException {
		for (Direction d : Direction.values()) {
			if (value == d.inner) {
				return d;
			}
		}
		String reason = String.format("Unable to parse '%s' for enum %s", value, Direction.class);
		throw new DirectionParseException(reason, value);
	}

	public static Direction parse(String val) throws DirectionParseException {
		return parse(val.toUpperCase().charAt(0));
	}

	public Direction getClockwise() {
		return clockwise;
	}

	public Direction getAnticlockwise() {
		return anticlockwise;
	}
}
