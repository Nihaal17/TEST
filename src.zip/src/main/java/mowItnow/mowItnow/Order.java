package mowItnow.mowItnow;

public enum Order {
  GAUCHE('G') {
    @Override
    public void animate(Mower mower, int n, int m) {
      mower.moveAnticlockwise();
    }
  },
  DROITE('D') {
    @Override
    public void animate(Mower mower, int n, int m) {
      mower.moveClockwise();
    }
  },
  AVANCE('A') {
    @Override
    public void animate(Mower mower, int n, int m) {
      mower.moveForward(n, m);
    }
  };

  private final char inner;

  Order(final char val) {
    inner = val;
  }

  @Override
  public String toString() {
    return String.valueOf(inner);
  }

  /**
   * Parses the character argument as an order.
   *
   * @param value a {@code char} containing the {@code Order} representation to be
   *              parsed
   * @return the order value represented by the argument.
   * @throws OrderParseException if the char is not a parsable order.
   */
  public static Order parse(final char value) throws OrderParseException {
    for (Order d : Order.values()) {
      if (value == d.inner) {
        return d;
      }
    }
    throw new OrderParseException(value);
  }

  /**
   * Parses the string argument as an order.
   *
   * @param val a {@code String} containing the {@code Order} representation to be
   *            parsed
   * @return the order value represented by the argument.
   * @throws OrderParseException if the string does not contain a parsable order.
   */
  public static Order parse(final String val) throws OrderParseException {
    return parse(val.toUpperCase().charAt(0));
  }

  /**
   * Mode a {@code Mower} according to an order.
   *
   * @param mower Mower to move
   * @param n     Weight size of the area
   * @param m     Height size of the area
   */
  abstract void animate(Mower mower, int n, int m);
}
