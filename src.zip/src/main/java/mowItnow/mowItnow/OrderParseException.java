package mowItnow.mowItnow;

public class OrderParseException extends Exception {
  private static final long serialVersionUID = 9167261533925096815L;
  private final char value;

  /**
   * @return the value of the error token
   */
  public char getValue() {
    return value;
  }

  /**
   * @param value2 Token in error
   */
  public OrderParseException(char value2) {
    super(String.format("Unable to parse '%s' for enum %s", value2, Order.class));
    this.value = value2;
  }
}
